#undef VERSION
#undef PACKAGE
